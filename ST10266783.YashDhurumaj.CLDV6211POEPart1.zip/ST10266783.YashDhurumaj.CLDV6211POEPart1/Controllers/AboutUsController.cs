﻿using Microsoft.AspNetCore.Mvc;

namespace ST10266783.YashDhurumaj.CLDV6211POEPart1.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
